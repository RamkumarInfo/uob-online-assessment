using Library.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace Library.Infrastructure.Persistence
{
    public class LibraryDbContext : DbContext
    {
        public LibraryDbContext(DbContextOptions<LibraryDbContext> options) : base(options) { }

        public DbSet<Book> Books => Set<Book>();
        public DbSet<Author> Authors => Set<Author>();
        public DbSet<BookCopy> BookCopies => Set<BookCopy>();
        public DbSet<Member> Members => Set<Member>();
        public DbSet<Loan> Loans => Set<Loan>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Book>(b =>
            {
                b.HasKey(x => x.Id);
                b.Property(x => x.Title).IsRequired().HasMaxLength(500);
            });

            modelBuilder.Entity<BookCopy>(bc =>
            {
                bc.HasKey(x => x.Id);
                bc.Property(x => x.Barcode).HasMaxLength(200);
            });

            modelBuilder.Entity<Member>(m =>
            {
                m.HasKey(x => x.Id);
                m.Property(x => x.FullName).HasMaxLength(200);
            });

            modelBuilder.Entity<Loan>(l =>
            {
                l.HasKey(x => x.Id);
            });
        }

        // Seed helper for demo (EnsureCreated + simple seed)
        public static void EnsureSeedData(LibraryDbContext db)
        {
            if (db.Books.Any()) return;

            var a1 = new Author { Id = Guid.Parse("11111111-1111-1111-1111-111111111111"), FullName = "J. K. Rowling" };
            var a2 = new Author { Id = Guid.Parse("22222222-2222-2222-2222-222222222222"), FullName = "George R. R. Martin" };

            var b1 = new Book { Id = Guid.Parse("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"), Title = "Harry Potter and the Philosopher's Stone", ISBN = "9780590353427", Publisher = "Scholastic" };
            var b2 = new Book { Id = Guid.Parse("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"), Title = "A Game of Thrones", ISBN = "9780553103540", Publisher = "Bantam" };

            var m1 = new Member { Id = Guid.Parse("33333333-3333-3333-3333-333333333333"), FullName = "Bruce Kumar", Email = "bruce@example.com" };
            var m2 = new Member { Id = Guid.Parse("44444444-4444-4444-4444-444444444444"), FullName = "Raja Mani", Email = "raja@example.com" };

            var c1 = new BookCopy { Id = Guid.Parse("dddddddd-dddd-dddd-dddd-dddddddddddd"), BookId = b1.Id, Barcode = "BC-0001", Status = CopyStatus.Available };
            var c2 = new BookCopy { Id = Guid.Parse("eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee"), BookId = b2.Id, Barcode = "BC-0002", Status = CopyStatus.Available };

            db.Authors.AddRange(a1, a2);
            db.Books.AddRange(b1, b2);
            db.Members.AddRange(m1, m2);
            db.BookCopies.AddRange(c1, c2);

            db.SaveChanges();
        }
    }
}
