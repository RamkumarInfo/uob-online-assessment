using Library.Application.Interfaces;
using Library.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Infrastructure.Persistence.Repositories
{
    public class MemberRepository : IMemberRepository
    {
        private readonly LibraryDbContext _db;
        public MemberRepository(LibraryDbContext db) { _db = db; }

        public async Task AddAsync(Member member, CancellationToken ct = default)
        {
            await _db.Members.AddAsync(member, ct);
            await _db.SaveChangesAsync(ct);
        }

        public async Task<IEnumerable<Member>> GetAllAsync(CancellationToken ct = default)
            => await _db.Members.ToListAsync(ct);

        public async Task<Member> GetByIdAsync(Guid id, CancellationToken ct = default)
            => await _db.Members.FindAsync(new object[] { id }, ct);

        public async Task UpdateAsync(Member member, CancellationToken ct = default)
        {
            _db.Members.Update(member);
            await _db.SaveChangesAsync(ct);
        }
    }
}
