using Library.Application.Interfaces;
using Library.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Infrastructure.Persistence.Repositories
{
    public class BookCopyRepository : IBookCopyRepository
    {
        private readonly LibraryDbContext _db;
        public BookCopyRepository(LibraryDbContext db) { _db = db; }

        public async Task AddAsync(BookCopy copy, CancellationToken ct = default)
        {
            await _db.BookCopies.AddAsync(copy, ct);
            await _db.SaveChangesAsync(ct);
        }

        public async Task<BookCopy> GetByIdAsync(Guid id, CancellationToken ct = default)
        {
            return await _db.BookCopies.FindAsync(new object[] { id }, ct);
        }

        public async Task<IEnumerable<BookCopy>> GetByBookIdAsync(Guid bookId, CancellationToken ct = default)
        {
            return await _db.BookCopies.Where(x => x.BookId == bookId).ToListAsync(ct);
        }

        public async Task UpdateAsync(BookCopy copy, CancellationToken ct = default)
        {
            _db.BookCopies.Update(copy);
            await _db.SaveChangesAsync(ct);
        }
    }
}
