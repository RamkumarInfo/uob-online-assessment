using Library.Application.Interfaces;
using Library.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Infrastructure.Persistence.Repositories
{
    public class LoanRepository : ILoanRepository
    {
        private readonly LibraryDbContext _db;
        public LoanRepository(LibraryDbContext db) { _db = db; }

        public async Task AddAsync(Loan loan, CancellationToken ct = default)
        {
            await _db.Loans.AddAsync(loan, ct);
            await _db.SaveChangesAsync(ct);
        }

        public async Task<Loan> GetByIdAsync(Guid id, CancellationToken ct = default)
            => await _db.Loans.FindAsync(new object[] { id }, ct);

        public async Task<IEnumerable<Loan>> GetActiveLoansByMemberAsync(Guid memberId, CancellationToken ct = default)
        {
            return await _db.Loans
                .Where(l => l.MemberId == memberId && l.Status == LoanStatus.Active)
                .ToListAsync(ct);
        }

        public async Task UpdateAsync(Loan loan, CancellationToken ct = default)
        {
            _db.Loans.Update(loan);
            await _db.SaveChangesAsync(ct);
        }
    }
}
