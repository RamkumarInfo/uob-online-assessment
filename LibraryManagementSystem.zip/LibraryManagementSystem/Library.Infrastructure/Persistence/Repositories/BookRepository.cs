using Library.Application.Interfaces;
using Library.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Infrastructure.Persistence.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly LibraryDbContext _db;
        public BookRepository(LibraryDbContext db) { _db = db; }

        public async Task AddAsync(Book book, CancellationToken ct = default)
        {
            await _db.Books.AddAsync(book, ct);
            await _db.SaveChangesAsync(ct);
        }

        public async Task DeleteAsync(Guid id, CancellationToken ct = default)
        {
            var book = await _db.Books.FindAsync(new object[] { id }, ct);
            if (book == null) return;
            _db.Books.Remove(book);
            await _db.SaveChangesAsync(ct);
        }

        public async Task<IEnumerable<Book>> GetAllAsync(CancellationToken ct = default)
            => await _db.Books.ToListAsync(ct);

        public async Task<Book> GetByIdAsync(Guid id, CancellationToken ct = default)
            => await _db.Books.FindAsync(new object[] { id }, ct);

        public async Task UpdateAsync(Book book, CancellationToken ct = default)
        {
            _db.Books.Update(book);
            await _db.SaveChangesAsync(ct);
        }
    }
}
