using System;

namespace Library.Domain.Entities
{
    public enum CopyStatus : byte { Available = 0, Loaned = 1, Reserved = 2, Lost = 3 }

    public class BookCopy
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid BookId { get; set; }
        public string Barcode { get; set; } = string.Empty;
        public CopyStatus Status { get; set; } = CopyStatus.Available;
        public DateTime AddedAt { get; set; } = DateTime.UtcNow;
    }
}
