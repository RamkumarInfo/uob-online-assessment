using System;

namespace Library.Domain.Entities
{
    public class Author
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string FullName { get; set; } = string.Empty;
        public string Bio { get; set; } = string.Empty;
    }
}
