using System;

namespace Library.Domain.Entities
{
    public enum LoanStatus : byte { Active = 0, Returned = 1, Overdue = 2, Cancelled = 3 }

    public class Loan
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid CopyId { get; set; }
        public Guid MemberId { get; set; }
        public DateTime LoanDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public decimal FineAmount { get; set; } = 0;
        public LoanStatus Status { get; set; } = LoanStatus.Active;
    }
}
