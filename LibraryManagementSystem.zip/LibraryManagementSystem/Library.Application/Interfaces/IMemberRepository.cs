using Library.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Application.Interfaces
{
    public interface IMemberRepository
    {
        Task<Member?> GetByIdAsync(Guid id, CancellationToken ct = default);
        Task<IEnumerable<Member>> GetAllAsync(CancellationToken ct = default);
        Task AddAsync(Member member, CancellationToken ct = default);
        Task UpdateAsync(Member member, CancellationToken ct = default);
    }
}
