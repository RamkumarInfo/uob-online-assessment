using Library.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Library.Application.Interfaces
{
    public interface IBookCopyRepository
    {
        Task<BookCopy?> GetByIdAsync(Guid id, CancellationToken ct = default);
        Task<IEnumerable<BookCopy>> GetByBookIdAsync(Guid bookId, CancellationToken ct = default);
        Task AddAsync(BookCopy copy, CancellationToken ct = default);
        Task UpdateAsync(BookCopy copy, CancellationToken ct = default);
    }
}
