using Library.Application.Interfaces;
using Library.Domain.Entities;
using System;
using System.Threading.Tasks;

namespace Library.Application.Services
{
    public class BorrowService
    {
        private readonly ILoanRepository _loanRepo;
        private readonly IBookCopyRepository _copyRepo;
        private readonly IMemberRepository _memberRepo;
        private readonly IBookRepository _bookRepo;

        public BorrowService(ILoanRepository loanRepo, IBookCopyRepository copyRepo, IMemberRepository memberRepo, IBookRepository bookRepo)
        {
            _loanRepo = loanRepo;
            _copyRepo = copyRepo;
            _memberRepo = memberRepo;
            _bookRepo = bookRepo;
        }

        public async Task<(bool Success, string? Error, Guid? LoanId)> BorrowAsync(Guid copyId, Guid memberId, int days)
        {
            var copy = await _copyRepo.GetByIdAsync(copyId);
            if (copy == null) return (false, "Copy not found", null);
            if (copy.Status != CopyStatus.Available) return (false, "Copy not available", null);

            var member = await _memberRepo.GetByIdAsync(memberId);
            if (member == null) return (false, "Member not found", null);
            if (!member.IsActive) return (false, "Member inactive", null);

            var loan = new Loan { CopyId = copyId, MemberId = memberId, LoanDate = DateTime.UtcNow, DueDate = DateTime.UtcNow.AddDays(days) };
            copy.Status = CopyStatus.Loaned;

            await _loanRepo.AddAsync(loan);
            await _copyRepo.UpdateAsync(copy);

            return (true, null, loan.Id);
        }
    }
}
