using Library.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace Library.API.Controllers
{
    [ApiController]
    [Route("api/v1/loans")]
    public class LoansController : ControllerBase
    {
        private readonly BorrowService _borrowService;

        public LoansController(BorrowService borrowService)
        {
            _borrowService = borrowService;
        }

        [HttpPost("borrow")]
        public async Task<IActionResult> Borrow([FromBody] BorrowDto dto)
        {
            var result = await _borrowService.BorrowAsync(dto.CopyId, dto.MemberId, dto.Days);
            if (!result.Success) return BadRequest(result.Error);
            return CreatedAtAction(null, new { id = result.LoanId }, null);
        }

        public class BorrowDto { public Guid CopyId { get; set; } public Guid MemberId { get; set; } public int Days { get; set; } = 14; }
    }
}
